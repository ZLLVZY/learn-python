#! /user/local/bin/python3
import cgitb
cgitb.enable()
import cgi
import athletemodel
import yate

athletes=athletemodel.get_from_store()

from_data=cgi.FieldStorage()
athlete_name=from_data['which_athlete'].value

print(yate.start_response())
print(yate.include_header("Zhang Liang's Timing Data"))
print(yate.header("Athlete:"+athlete_name+",DOB:"+athletes[athlete_name].dob)+".")
print(yate.para("The top times for this athlete are:"))
print(yate.u_list(athletes[athlete_name].top3))
print(yate.include_footer({"Home":"/index.html","Select another athlete":"generate_list.py"}))